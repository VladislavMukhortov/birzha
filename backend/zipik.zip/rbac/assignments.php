<?php
return [
    // ID пользователя
    1 => [
        // роль
        'admin',
    ]
];
