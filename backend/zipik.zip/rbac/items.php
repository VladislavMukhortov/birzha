<?php
return [
    'admin' => [
        'type' => 1,
    ],
];
