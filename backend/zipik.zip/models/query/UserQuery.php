<?php
declare(strict_types=1);

namespace app\models\query;

use Yii;
use yii\db\ActiveQuery;

use app\models\User;

class UserQuery extends ActiveQuery
{

}
