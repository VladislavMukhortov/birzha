<?php

use yii\helpers\Url;
use yii\helpers\Html;

$this->title = 'admin dashboard';

?>
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-8 m-auto">

                <h2><?php echo h($this->title) ?></h2>

            </div>
        </div>
    </div>
</section>

